
import React from 'react';
import { LogoIcon, InstagramIcon, FacebookIcon, WhatsAppIcon } from './Icons';

interface FooterProps {
    onTermsClick: () => void;
}


const Footer: React.FC<FooterProps> = ({ onTermsClick }) => {
    return (
        <footer id="contact" className="bg-zinc-900 text-white dark:bg-custom-purple-footer">
            <div className="container mx-auto px-6 py-12">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* About Section */}
                    <div>
                        <div className="flex items-center space-x-2 mb-4">
                            <LogoIcon />
                            <span className="text-xl font-bold">Emak Laundry</span>
                        </div>
                        <p className="text-zinc-400 dark:text-zinc-300">"Kebersihan Terbaik dengan Sentuhan Kasih Ibu." Solusi laundry terpercaya di Kota Banjar.</p>
                    </div>
                    
                    {/* Contact Info Section */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4">Hubungi Kami</h3>
                        <address className="space-y-3 text-zinc-400 dark:text-zinc-300 not-italic">
                            <p className="flex items-start">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 mt-1 text-custom-purple-light flex-shrink-0" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                                Jl. Dr. Sudarsono No.43, Mekarsari, Kec. Banjar, Kota Banjar, Jawa Barat 46321
                            </p>
                            <p className="flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 text-custom-purple-light" viewBox="0 0 20 20" fill="currentColor"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" /></svg>
                                <a href="https://wa.me/6285175279659" className="hover:text-custom-purple-light dark:hover:text-custom-purple-light">0851 7527 9659</a>
                            </p>
                            <p className="flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 text-custom-purple-light" viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" /><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" /></svg>
                                <a href="mailto:emaklaundry12@gmail.com" className="hover:text-custom-purple-light dark:hover:text-custom-purple-light">emaklaundry12@gmail.com</a>
                            </p>
                        </address>
                    </div>
                    
                    {/* Social Media Section */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4">Ikuti Kami</h3>
                        <div className="flex space-x-4">
                           <a href="https://www.instagram.com/emaklaundry12" target="_blank" rel="noopener noreferrer" className="text-zinc-400 dark:text-zinc-300 hover:text-custom-purple-light dark:hover:text-custom-purple-light transition-colors" aria-label="Instagram">
                                <span className="sr-only">Instagram</span>
                                <InstagramIcon/>
                            </a>
                            <a href="https://www.facebook.com/emaklaundry" target="_blank" rel="noopener noreferrer" className="text-zinc-400 dark:text-zinc-300 hover:text-custom-purple-light dark:hover:text-custom-purple-light transition-colors" aria-label="Facebook">
                                <span className="sr-only">Facebook</span>
                                <FacebookIcon />
                            </a>
                            <a href="https://wa.me/6285175279659" target="_blank" rel="noopener noreferrer" className="text-zinc-400 dark:text-zinc-300 hover:text-custom-purple-light dark:hover:text-custom-purple-light transition-colors" aria-label="WhatsApp">
                                <span className="sr-only">WhatsApp</span>
                                <WhatsAppIcon />
                            </a>
                        </div>
                         <h3 className="text-lg font-semibold mb-4 mt-6">Jam Operasional</h3>
                         <p className="text-zinc-400 dark:text-zinc-300">Setiap Hari: 08:00 - 20:00 WIB</p>
                    </div>
                </div>
                
                <div className="mt-12 border-t border-zinc-700 dark:border-custom-purple-border pt-8 text-center text-zinc-500 dark:text-zinc-400 sm:flex sm:justify-between sm:items-center">
                    <p className="mb-4 sm:mb-0">&copy; {new Date().getFullYear()} Emak Laundry. Semua Hak Cipta Dilindungi.</p>
                    <button 
                        onClick={onTermsClick} 
                        className="bg-zinc-800 hover:bg-zinc-700 dark:bg-custom-purple-border/50 dark:hover:bg-custom-purple-border text-zinc-300 dark:text-zinc-200 font-medium py-2 px-4 rounded-lg transition-colors text-sm"
                    >
                        Syarat & Ketentuan
                    </button>
                </div>
            </div>
        </footer>
    );
};

export default Footer;